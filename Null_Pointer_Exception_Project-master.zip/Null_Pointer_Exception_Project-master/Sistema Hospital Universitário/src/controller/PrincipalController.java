/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import com.jfoenix.controls.JFXButton;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author serbi
 */
public class PrincipalController implements Initializable {

    @FXML
    private ImageView Icon;

    @FXML
    private Label Nome1;

    @FXML
    private Label Nome2;

    @FXML
    private Label tituloLabel;

    @FXML
    private JFXButton cadastrarAluno;

    @FXML
    private ImageView Icon1;

    @FXML
    private JFXButton cadastrarProfessor;

    @FXML
    private ImageView Icon11;

    @FXML
    private JFXButton cadastrarPaciente;

    @FXML
    private ImageView Icon111;

    @FXML
    private JFXButton Relatorios;

    @FXML
    private ImageView Icon1111;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
