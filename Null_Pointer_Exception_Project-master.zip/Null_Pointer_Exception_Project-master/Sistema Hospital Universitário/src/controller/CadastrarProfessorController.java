/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import model.dao.ProfessorDAO;
import model.domain.Professor;
import view.CadastrarProfessor;
import view.MainFrame;

/**
 * FXML Controller class
 *
 * @author serbi
 */
public class CadastrarProfessorController implements Initializable {

    @FXML
    private ImageView Icon;

    @FXML
    private Label Nome1;

    @FXML
    private Label Nome2;

    @FXML
    private JFXTextField nomeField;

    @FXML
    private JFXTextField crmField;

    @FXML
    private JFXPasswordField senhaField;

    @FXML
    private JFXTextField titulacaoField;

    @FXML
    private JFXTextField matriculaField;

    @FXML
    private Label tituloLabel;

    @FXML
    private JFXButton cadastrar;

    @FXML
    private JFXButton cancelar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    public void cadastrarAction(ActionEvent event) {
        ProfessorDAO professorDAO = new ProfessorDAO();
        String nome = nomeField.getText().trim().toUpperCase();
        String matricula = matriculaField.getText().trim().concat("P");
        String senha = senhaField.getText();
        String titulacao = titulacaoField.getText().trim();
        String crm = crmField.getText().trim();
        Professor professor = new Professor(nome, matricula, senha, crm, titulacao);
        boolean result = professorDAO.create(professor);
        Alert alert;
        if (!result) {
            alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("Information Dialog");
            alert.setContentText("Cadastro realizado com sucesso!");
        } else {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Information Dialog");
            alert.setContentText("Erro ao realizar cadastro.");
        }
        alert.showAndWait();
        CadastrarProfessor.getStage().close();
        MainFrame.getStage().show();
    }

    @FXML
    public void cancelarAction(ActionEvent event) {
        CadastrarProfessor.getStage().close();
        MainFrame.getStage().show();
    }
}
