/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import view.CadastrarAluno;
import view.MainFrame;
import model.dao.AlunoDAO;
import model.domain.Aluno;

/**
 * FXML Controller class
 *
 * @author serbi
 */
public class CadastrarAlunoController implements Initializable {

    @FXML
    private ImageView Icon;

    @FXML
    private Label Nome1;

    @FXML
    private Label Nome2;

    @FXML
    private JFXTextField nomeField;

    @FXML
    private JFXTextField matriculaField;

    @FXML
    private JFXPasswordField senhaField;

    @FXML
    private JFXTextField anoResidenciaField;

    @FXML
    private JFXDatePicker dataNascimentoField;

    @FXML
    private JFXTextField crmProfessorField;

    @FXML
    private Label tituloLabel;

    @FXML
    private JFXButton cadastrar;

    @FXML
    private JFXButton cancelar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    public void cadastrarAcao(ActionEvent event) {
        AlunoDAO alunoDAO = new AlunoDAO();
        String nome = this.nomeField.getText().trim();
        String matricula = this.matriculaField.getText().trim().concat("A");
        String senha = this.senhaField.getText();
        String anoResidencia = this.anoResidenciaField.getText().trim();
        LocalDate dataNascimento = this.dataNascimentoField.getValue();
        String crmProfessor = this.crmProfessorField.getText().trim();
        Aluno aluno = new Aluno(nome, matricula, senha, Integer.parseInt(anoResidencia), dataNascimento);
        boolean result = alunoDAO.create(aluno, crmProfessor);
        Alert alert;
        if (!result) {
            alert = new Alert(AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("Information Dialog");
            alert.setContentText("Cadastro realizado com sucesso!");
        } else {
            alert = new Alert(AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Information Dialog");
            alert.setContentText("Erro ao realizar cadastro.");
        }
        alert.showAndWait();
        CadastrarAluno.getStage().close();
        MainFrame.getStage().show();
    }
    @FXML
    public void cancelarAcao(ActionEvent event) {
        CadastrarAluno.getStage().close();
        MainFrame.getStage().show();
    }
}
