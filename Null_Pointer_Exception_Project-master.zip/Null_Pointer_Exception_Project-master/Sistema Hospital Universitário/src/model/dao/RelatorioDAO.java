package model.dao;

import java.sql.Connection;

public class RelatorioDAO {
    
    private Connection connection;
}
