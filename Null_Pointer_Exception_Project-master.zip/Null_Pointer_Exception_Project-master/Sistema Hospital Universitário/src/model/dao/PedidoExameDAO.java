package model.dao;

import java.sql.Connection;

public class PedidoExameDAO {
    
    private Connection connection;
}
