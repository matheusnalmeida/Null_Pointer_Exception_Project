# Null_Pointer_Exception_Project
Projeto para a materia de laboratório de engenharia de software.
# Detalhes do projeto: 
- Linguagem de programação: Java
- Banco de dados: MySQL
- Segmento: Desktop
